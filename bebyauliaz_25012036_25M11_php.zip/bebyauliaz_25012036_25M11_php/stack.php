<?php
$pageTitle = "Stack Simulator";
$stack = isset($_POST['stack']) ? array_values(array_filter(array_map('trim', explode('|', $_POST['stack'])))) : ['Buku','Laptop','Kunci'];
$action = $_POST['action'] ?? '';
$message = '';

if ($action === 'push' && isset($_POST['value']) && trim($_POST['value']) !== '') {
    $stack[] = trim($_POST['value']);
    $message = "Push berhasil: data masuk ke TOP.";
}
if ($action === 'pop' && count($stack) > 0) {
    $removed = array_pop($stack);
    $message = "Pop berhasil: '$removed' keluar dari TOP.";
}
if ($action === 'peek') {
    $message = count($stack) ? "Peek: data paling atas adalah '".$stack[count($stack)-1]."'." : "Stack kosong.";
}
include "includes/header.php";
?>
<div class="page-head">
    <span class="badge">STRUKTUR 03</span>
    <h1>Stack Simulator</h1>
    <p>Stack menggunakan prinsip <b>LIFO (Last In, First Out)</b>: data terakhir masuk menjadi data pertama yang keluar.</p>
</div>

<?php if ($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>

<form method="post" class="panel">
    <input type="hidden" name="stack" value="<?= htmlspecialchars(implode('|', $stack)) ?>">
    <label>Operasi Stack</label>
    <div class="row">
        <input name="value" placeholder="Data untuk Push">
        <button name="action" value="push">Push ↑</button>
        <button name="action" value="pop" class="danger">Pop ↓</button>
        <button name="action" value="peek" class="secondary">Peek</button>
    </div>
</form>

<div class="stack-wrap">
    <div class="top-label">TOP</div>
    <div class="stack">
        <?php if (!$stack): ?><div class="empty">Stack kosong</div><?php endif; ?>
        <?php for ($i = count($stack)-1; $i >= 0; $i--): ?>
            <div class="stack-item"><?= htmlspecialchars($stack[$i]) ?><?= $i === count($stack)-1 ? ' <b>← TOP</b>' : '' ?></div>
        <?php endfor; ?>
    </div>
    <div class="bottom-label">BOTTOM</div>
</div>

<div class="explain">
    <h3>Cara kerja</h3>
    <ol>
        <li><b>Push</b> menambahkan data ke TOP.</li>
        <li><b>Pop</b> mengeluarkan data dari TOP.</li>
        <li><b>Peek</b> melihat data TOP tanpa menghapusnya.</li>
        <li>Contoh penggunaan: undo/redo, riwayat halaman, dan call stack.</li>
    </ol>
</div>
<?php include "includes/footer.php"; ?>