<?php
$pageTitle = "Array Simulator";
$items = isset($_POST['items']) ? array_values(array_filter(array_map('trim', explode(',', $_POST['items'])))) : ['Apel','Jeruk','Mangga'];
$action = $_POST['action'] ?? '';
$message = '';

if ($action === 'add' && isset($_POST['value']) && trim($_POST['value']) !== '') {
    $items[] = trim($_POST['value']);
    $message = "Data berhasil ditambahkan ke indeks terakhir.";
}
if ($action === 'delete' && count($items) > 0) {
    $removed = array_pop($items);
    $message = "Data terakhir ($removed) berhasil dihapus.";
}
if ($action === 'search' && isset($_POST['value'])) {
    $needle = trim($_POST['value']);
    $found = array_search($needle, $items);
    $message = ($found !== false) ? "Data '$needle' ditemukan pada indeks $found." : "Data '$needle' tidak ditemukan.";
}
include "includes/header.php";
?>
<div class="page-head">
    <span class="badge">STRUKTUR 01</span>
    <h1>Array Simulator</h1>
    <p>Array menyimpan elemen dalam urutan indeks. Pada PHP, array dapat dikelola secara dinamis.</p>
</div>

<?php if ($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>

<form method="post" class="panel">
    <input type="hidden" name="items" value="<?= htmlspecialchars(implode(',', $items)) ?>">
    <label>Tambah data</label>
    <div class="row">
        <input name="value" placeholder="Contoh: Semangka">
        <button name="action" value="add">Tambah</button>
        <button name="action" value="delete" class="danger">Hapus Terakhir</button>
    </div>
</form>

<form method="post" class="panel">
    <input type="hidden" name="items" value="<?= htmlspecialchars(implode(',', $items)) ?>">
    <label>Cari data</label>
    <div class="row">
        <input name="value" placeholder="Masukkan data yang dicari">
        <button name="action" value="search">Cari</button>
    </div>
</form>

<div class="structure">
<?php foreach ($items as $i => $item): ?>
    <div class="node">
        <small>index <?= $i ?></small>
        <strong><?= htmlspecialchars($item) ?></strong>
    </div>
<?php endforeach; ?>
</div>

<div class="explain">
    <h3>Cara kerja</h3>
    <ol>
        <li>Setiap data memiliki indeks.</li>
        <li><b>Tambah</b> menambahkan elemen di posisi akhir.</li>
        <li><b>Hapus Terakhir</b> menghapus elemen terakhir menggunakan <code>array_pop()</code>.</li>
        <li><b>Cari</b> menggunakan <code>array_search()</code>.</li>
    </ol>
</div>
<?php include "includes/footer.php"; ?>