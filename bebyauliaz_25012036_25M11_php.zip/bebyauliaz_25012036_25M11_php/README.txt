PROJECT PHP STRUKTUR DATA LINEAR
Nama: Beby Aulia Zahara
NIM: 25012036
Kelas: 25M11

Struktur:
- index.php       : halaman utama
- array.php       : simulasi Array
- linkedlist.php  : simulasi Linked List
- stack.php       : simulasi Stack
- includes/       : header dan footer
- assets/         : CSS dan JavaScript

Cara menjalankan:
1. Install XAMPP atau Laragon.
2. Salin folder bebyauliaz_25012036_25M11_php ke htdocs.
3. Jalankan Apache.
4. Buka http://localhost/bebyauliaz_25012036_25M11_php/
