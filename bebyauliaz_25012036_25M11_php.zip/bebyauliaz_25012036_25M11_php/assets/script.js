document.addEventListener("DOMContentLoaded", () => {
  document.querySelectorAll(".node,.stack-item").forEach((el,i)=>{
    el.animate([{opacity:0,transform:"translateY(8px)"},{opacity:1,transform:"translateY(0)"}],{duration:350,delay:i*60,fill:"both"});
  });
});