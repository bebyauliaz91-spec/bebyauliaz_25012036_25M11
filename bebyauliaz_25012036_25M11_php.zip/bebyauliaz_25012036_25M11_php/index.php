<?php
$pageTitle = "Linear Data Structures";
include "includes/header.php";
?>
<div class="hero">
    <div>
        <span class="badge">PHP • DATA STRUCTURE</span>
        <h1>Linear Data Structures</h1>
        <p>Pelajari cara kerja <b>Array</b>, <b>Linked List</b>, dan <b>Stack</b> melalui simulasi interaktif.</p>
        <div class="hero-actions">
            <a class="btn" href="array.php">Mulai Array →</a>
            <a class="btn secondary" href="linkedlist.php">Linked List</a>
            <a class="btn secondary" href="stack.php">Stack</a>
        </div>
    </div>
</div>

<div class="cards">
    <a class="card" href="array.php">
        <div class="icon">01</div>
        <h2>Array</h2>
        <p>Data disimpan pada indeks berurutan. Coba tambah, hapus, dan cari data.</p>
    </a>
    <a class="card" href="linkedlist.php">
        <div class="icon">02</div>
        <h2>Linked List</h2>
        <p>Node terhubung menggunakan pointer <code>next</code>. Coba insert dan delete node.</p>
    </a>
    <a class="card" href="stack.php">
        <div class="icon">03</div>
        <h2>Stack</h2>
        <p>Menggunakan konsep LIFO: data terakhir masuk akan keluar terlebih dahulu.</p>
    </a>
</div>

<div class="info-box">
    <h3>Tujuan Project</h3>
    <p>Project ini menunjukkan implementasi struktur data linear menggunakan PHP dengan antarmuka web yang interaktif.</p>
</div>
<?php include "includes/footer.php"; ?>