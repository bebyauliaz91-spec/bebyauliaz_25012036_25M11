</main>
<footer>
    <p>Project PHP Struktur Data Linear • Beby Aulia Zahara • 25012036 • 25M11</p>
</footer>
<script src="assets/script.js"></script>
</body>
</html>