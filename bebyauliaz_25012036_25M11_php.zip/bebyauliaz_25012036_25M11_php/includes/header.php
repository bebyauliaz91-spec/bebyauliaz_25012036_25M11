<!DOCTYPE html>
<html lang="id">
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title><?= htmlspecialchars($pageTitle) ?> | Linear Data Structures</title>
<link rel="stylesheet" href="assets/style.css">
</head>
<body>
<header class="navbar">
    <a class="brand" href="index.php">Beby<span>DS</span></a>
    <nav>
        <a href="index.php">Home</a>
        <a href="array.php">Array</a>
        <a href="linkedlist.php">Linked List</a>
        <a href="stack.php">Stack</a>
    </nav>
</header>
<main class="container">