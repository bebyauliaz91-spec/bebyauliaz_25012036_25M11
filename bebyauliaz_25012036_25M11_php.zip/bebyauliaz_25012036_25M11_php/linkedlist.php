<?php
$pageTitle = "Linked List Simulator";
$nodes = isset($_POST['nodes']) ? array_values(array_filter(array_map('trim', explode('|', $_POST['nodes'])))) : ['Node A','Node B','Node C'];
$action = $_POST['action'] ?? '';
$message = '';

if ($action === 'insert' && isset($_POST['value']) && trim($_POST['value']) !== '') {
    array_unshift($nodes, trim($_POST['value']));
    $message = "Node baru berhasil disisipkan di awal linked list.";
}
if ($action === 'append' && isset($_POST['value']) && trim($_POST['value']) !== '') {
    $nodes[] = trim($_POST['value']);
    $message = "Node baru berhasil ditambahkan di akhir linked list.";
}
if ($action === 'delete' && count($nodes) > 0) {
    $removed = array_shift($nodes);
    $message = "Node '$removed' berhasil dihapus dari awal.";
}
include "includes/header.php";
?>
<div class="page-head">
    <span class="badge">STRUKTUR 02</span>
    <h1>Linked List Simulator</h1>
    <p>Setiap node menyimpan data dan hubungan ke node berikutnya melalui konsep <code>next</code>.</p>
</div>

<?php if ($message): ?><div class="message"><?= htmlspecialchars($message) ?></div><?php endif; ?>

<form method="post" class="panel">
    <input type="hidden" name="nodes" value="<?= htmlspecialchars(implode('|', $nodes)) ?>">
    <label>Kelola Node</label>
    <div class="row">
        <input name="value" placeholder="Nama node baru">
        <button name="action" value="insert">Insert Awal</button>
        <button name="action" value="append">Append Akhir</button>
        <button name="action" value="delete" class="danger">Delete Awal</button>
    </div>
</form>

<div class="linked-structure">
<?php foreach ($nodes as $i => $node): ?>
    <div class="link-item">
        <div class="node">
            <small>Node <?= $i + 1 ?></small>
            <strong><?= htmlspecialchars($node) ?></strong>
            <span>data</span>
        </div>
        <?php if ($i < count($nodes)-1): ?><div class="arrow">→ next</div><?php else: ?><div class="null">→ NULL</div><?php endif; ?>
    </div>
<?php endforeach; ?>
</div>

<div class="explain">
    <h3>Cara kerja</h3>
    <ol>
        <li>Linked list terdiri dari node-node yang saling terhubung.</li>
        <li><b>Insert Awal</b> menambahkan node di depan.</li>
        <li><b>Append Akhir</b> menambahkan node di belakang.</li>
        <li><b>Delete Awal</b> menghapus node pertama lalu hubungan bergeser.</li>
    </ol>
</div>
<?php include "includes/footer.php"; ?>